# Jisr / جسر — Free bilingual starter website

This is a simple static Arabic-English website. It can be hosted on a free static hosting plan.

## Files
- `index.html` — home page, services, process, free sample, contact form.
- `cv-template.txt` — free text CV outline.

## Before publishing
1. Open `index.html` in a text editor.
2. Find `YOUR_EMAIL@example.com` and replace it with a real email address you want customers to contact.
3. Review service scope and prices; prices are placeholders, not validated market rates.
4. Open `index.html` in your browser to test Arabic/English toggle and links.

## Free publishing option: GitHub Pages
1. Create a free GitHub account at https://github.com/
2. Create a new public repository, e.g. `jisr-site`.
3. Upload `index.html` and `cv-template.txt` to the repository root.
4. Open repository Settings → Pages.
5. Under Build and deployment, choose “Deploy from a branch”, select `main` and `/ (root)`, then Save.
6. Wait for GitHub Pages to publish and use the URL shown in Settings → Pages.

Free hosting terms and availability can change. A custom domain is optional and usually costs money; start with the free provided URL.

## Important practical notes
- The contact form uses `mailto:`. It opens the visitor's email app; it does not store submissions on a server. Replace the placeholder email first.
- No payment checkout is included. For the first clients, agree on scope, delivery time, and payment method directly before starting work. Do not promise outcomes you cannot guarantee.
- If operating from Germany or another country, check applicable business registration, tax, privacy, consumer, and right-to-work requirements before accepting paid orders.
- Avoid collecting sensitive personal information. Never request passwords, bank details, or identity numbers.
